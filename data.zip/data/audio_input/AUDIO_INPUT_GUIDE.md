# Audio Input Guide

## 📁 Sample Audio Files

This directory contains sample MP3 audio files for testing the voice input functionality of VoiceOps AI.

### Available Sample Files

 File Name | Description | Use Case |
-----------|-------------|----------|
 `sample_greeting.mp3` | Greeting audio sample | Test greeting intent detection |
 `sample_task_query.mp3` | Task query audio | Test task-related queries |
 `sample_note_save.mp3` | Note saving request | Test note-taking functionality |

---

## 🎤 Recording Your Own Audio Files

### Using Whisper STT
The application uses OpenAI Whisper for speech-to-text transcription, which supports:

**Supported Audio Formats:**
- MP3
- WAV
- M4A
- FLAC
- OGG

**Recommended Settings:**
- Sample Rate: 16kHz or 44.1kHz
- Channels: Mono (1 channel)
- Bit Rate: 64-128 kbps for MP3
- Duration: 1-30 seconds for best results

---

## 🎙️ Recording Audio Samples

### Method 1: Using Online Tools
1. **Vocaroo** (https://vocaroo.com/)
   - Click "Record"
   - Speak your query
   - Download as MP3

2. **Online Voice Recorder** (https://online-voice-recorder.com/)
   - Click microphone icon
   - Record your message
   - Save as MP3

### Method 2: Using Command Line (macOS/Linux)

#### macOS (using built-in tools)
```bash
# Record audio using QuickTime Player
# Or use Sox if installed:
sox -d -r 16000 -c 1 my_audio.mp3 trim 0 10
```

#### Linux (using arecord/ffmpeg)
```bash
# Record 10 seconds of audio
arecord -d 10 -f cd -t wav temp.wav
ffmpeg -i temp.wav -acodec libmp3lame my_audio.mp3
rm temp.wav
```

### Method 3: Using Python

```python
import sounddevice as sd
from scipy.io.wavfile import write
import subprocess

# Record audio
duration = 10  # seconds
sample_rate = 16000
print("Recording...")
audio = sd.rec(int(duration * sample_rate), 
               samplerate=sample_rate, 
               channels=1)
sd.wait()

# Save as WAV temporarily
write('temp.wav', sample_rate, audio)

# Convert to MP3
subprocess.run([
    'ffmpeg', '-i', 'temp.wav', 
    '-acodec', 'libmp3lame', 
    'my_audio.mp3'
])
```

---

## 🧪 Testing with Audio Files

### Enable Voice Mode
In `voiceops_ai/config.py`:
```python
VOICE_MODE = True
AUDIO_INPUT_DIR = Path("/path/to/audio_input/")
```

### Run with Audio Input
```python
from voiceops_ai import VoiceInputHandler

handler = VoiceInputHandler(
    voice_mode=True,
    audio_path="data/audio_input/sample_greeting.mp3",
    whisper_model="tiny"  # or "base", "small", "medium", "large"
)

text = handler.transcribe_audio()
print(f"Transcribed: {text}")
```

### Batch Testing
```python
import os
from pathlib import Path
from voiceops_ai import AgentOrchestrator

audio_dir = Path("data/audio_input")
agent = AgentOrchestrator()

for audio_file in audio_dir.glob("*.mp3"):
    print(f"\n🎤 Processing: {audio_file.name}")
    
    # Transcribe
    handler = VoiceInputHandler(
        voice_mode=True,
        audio_path=str(audio_file)
    )
    text = handler.transcribe_audio()
    
    # Process
    result = agent.run_turn(text)
    print(f"📝 Transcription: {text}")
    print(f"🎯 Intent: {result.detected_intent}")
    print(f"🤖 Response: {result.ai_response}")
```

---

## 📋 Sample Queries to Record

### Greetings
- "Hello, good morning!"
- "Hi there, how are you?"
- "Hey, what's up?"

### Task Queries
- "Show me today's tasks"
- "What do I have on my agenda?"
- "List all pending tasks"

### Note Saving
- "Save a note: Call the client tomorrow"
- "Remember to buy groceries"
- "Note to self: Update the documentation"

### Questions
- "What is machine learning?"
- "Explain artificial intelligence"
- "How does natural language processing work?"

### Reminders
- "Remind me to submit the report on June 25th at 10 AM"
- "Set a reminder for tomorrow at 3 PM"
- "Don't let me forget the meeting on Friday"

### Information Extraction
- "My email is john.doe@example.com"
- "You can reach me at plus one five five five one two three four five six seven"
- "Contact me at user@company.com or call five five five nine eight seven six five four three"

---

## 🎯 Best Practices

### Audio Quality
✅ **DO:**
- Use clear pronunciation
- Minimize background noise
- Speak at normal pace
- Use quality microphone
- Record in quiet environment

❌ **AVOID:**
- Mumbling or speaking too fast
- Recording in noisy locations
- Using low-quality microphones
- Clipping/distortion
- Very long recordings (>1 minute)

### File Naming
Use descriptive names that indicate content:
- `greeting_hello.mp3`
- `task_query_show_tasks.mp3`
- `note_save_call_client.mp3`
- `question_what_is_ml.mp3`
- `reminder_submit_report.mp3`

### Organization
```
audio_input/
├── greetings/
│   ├── hello_morning.mp3
│   └── hi_there.mp3
├── tasks/
│   ├── show_tasks.mp3
│   └── task_status.mp3
├── notes/
│   ├── save_note_client.mp3
│   └── remember_meeting.mp3
└── questions/
    ├── what_is_ml.mp3
    └── explain_ai.mp3
```

---

## 🔧 Troubleshooting

### Audio Not Transcribing
1. Check file format is supported
2. Verify file is not corrupted
3. Try re-encoding: `ffmpeg -i input.mp3 -acodec libmp3lame output.mp3`
4. Check audio duration (very short/long may fail)

### Poor Transcription Quality
1. Use higher quality Whisper model (`base` or `small`)
2. Improve audio quality (reduce noise)
3. Speak more clearly
4. Check microphone positioning

### File Not Found
1. Verify file path is correct
2. Use absolute paths
3. Check file permissions
4. Ensure file extension is correct

---

## 📊 Performance Considerations

 Whisper Model | Speed | Accuracy | Memory |
--------------|-------|----------|--------|
 tiny | Fastest | Good | ~1 GB |
 base | Fast | Better | ~1 GB |
 small | Medium | Good | ~2 GB |
 medium | Slow | Better | ~5 GB |
 large | Slowest | Best | ~10 GB |

**Recommendation:** Use `tiny` for development, `small` or `base` for production.

---

## 🎓 Additional Resources

- **Whisper Documentation:** https://github.com/openai/whisper
- **Audio Processing:** https://ffmpeg.org/
- **Python Audio:** https://python-sounddevice.readthedocs.io/

---

**For questions about audio input, refer to the main project documentation or the VoiceInputHandler class.**
