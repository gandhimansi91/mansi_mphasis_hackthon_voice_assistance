# VoiceOps AI - Data Catalog

**Last Updated:** 2024-06-16  
**Status:** Sample Data for Testing & Demonstration

---

## 📁 Directory Structure

```
data/
├── audio_input/          # Input files and test queries
├── audio_output/         # Generated TTS audio files (MP3)
├── logs/                 # Conversation logs and metrics
└── DATA_CATALOG.md       # This file
```

---

## 📊 Sample Data Inventory

### 1. Conversation Logs (`logs/`)

#### sample_conversation_log.csv
**Purpose:** Demonstration conversation history  
**Format:** CSV  
**Columns:** timestamp, session_id, turn_id, user_input, detected_intent, extracted_entities, ai_response, audio_file_path, processing_time_ms  
**Records:** 11 conversation turns across 2 sessions  
**Use Cases:**
- Training data visualization
- Analytics dashboard testing
- Intent distribution analysis
- Performance benchmarking

**Sample Sessions:**
- **Session 1:** a1b2c3d4-e5f6-7890-abcd-ef1234567890 (8 turns)
  - Complete conversation flow
  - Multiple intent types
  - Entity extraction examples
  
- **Session 2:** b2c3d4e5-f6a7-8901-bcde-f12345678901 (3 turns)
  - Follow-up session
  - Note summarization
  - Continuity testing

#### performance_metrics.csv
**Purpose:** System performance tracking  
**Format:** CSV  
**Columns:** timestamp, session_id, metric_name, metric_value, unit  
**Records:** 12 performance measurements  
**Metrics Tracked:**
- `response_time` - Total response time (ms)
- `audio_synthesis_time` - TTS generation time (ms)
- `llm_inference_time` - LLM processing time (ms)

**Use Cases:**
- Performance optimization
- Latency analysis
- Bottleneck identification

#### intent_distribution.csv
**Purpose:** Intent analytics summary  
**Format:** CSV  
**Columns:** intent, count, percentage, avg_response_time_ms  
**Records:** 7 intent categories  
**Intents Covered:**
- greeting (36.4%)
- question (18.2%)
- task_query (9.1%)
- note_save (9.1%)
- reminder_set (9.1%)
- farewell (9.1%)
- unknown (9.1%)

#### saved_notes.txt
**Purpose:** User's saved notes  
**Format:** Plain text with timestamps  
**Records:** 5 sample notes  
**Content:**
- Client communication reminders
- Documentation tasks
- Meeting scheduling
- Project updates

#### reminders.txt
**Purpose:** Scheduled reminders  
**Format:** Plain text with timestamps  
**Records:** 5 sample reminders  
**Content:**
- Report deadlines
- Meeting schedules
- Client calls
- Review sessions

#### tasks_database.txt
**Purpose:** Task management data  
**Format:** Structured plain text  
**Records:** 5 tasks  
**Fields:** TASK_ID, TITLE, DUE_DATE, STATUS, PRIORITY, DESCRIPTION, ASSIGNED_TO  
**Statuses:**
- in_progress (2 tasks)
- pending (1 task)
- scheduled (1 task)
- not_started (1 task)

#### error_logs.txt
**Purpose:** System error and warning logs  
**Format:** Plain text with log levels  
**Records:** 8 log entries  
**Log Levels:**
- ERROR (2 entries)
- WARNING (3 entries)
- INFO (3 entries)

**Common Issues Logged:**
- Audio transcription quality
- API rate limiting
- Network issues
- Storage capacity warnings
- Performance degradation

---

### 2. Audio Input (`audio_input/`)

#### sample_test_queries.txt
**Purpose:** Comprehensive test query collection  
**Format:** Plain text organized by category  
**Categories:** 11 sections  
**Total Queries:** 50+  
**Coverage:**
- Greeting intents (4 queries)
- Task queries (4 queries)
- Note saving (4 queries)
- Questions (4 queries)
- Reminders (4 queries)
- Summarization (4 queries)
- Contact extraction (4 queries)
- Complex multi-intent (4 queries)
- Farewells (4 queries)
- Edge cases (4 queries)

**Use Cases:**
- Automated testing
- Intent classifier training
- Regression testing
- Demo preparation

#### demo_scenarios.txt
**Purpose:** End-to-end demo scenarios  
**Format:** Structured conversation flows  
**Scenarios:** 5 complete scenarios  
**Content:**
- Morning productivity assistant
- Note-taking assistant
- Information extraction
- Knowledge Q&A
- Multi-turn task management

**Each Scenario Includes:**
- User inputs
- Expected responses
- Performance benchmarks
- Use case demonstrations

#### test_data_guide.txt
**Purpose:** Documentation for test data usage  
**Format:** Markdown  
**Content:**
- File descriptions
- Usage instructions
- Testing methodologies
- Performance benchmarks
- Adding new test cases

---

### 3. Audio Output (`audio_output/`)

**Purpose:** Generated TTS audio files  
**Format:** MP3  
**Current Files:** 8 sample audio files  
**Naming Convention:** `turn_{turn_id}_{session_id}.mp3`  

**Sample Files:**
- turn_1_93e62fbd.mp3
- turn_2_93e62fbd.mp3
- turn_3_93e62fbd.mp3
- turn_4_93e62fbd.mp3
- turn_5_93e62fbd.mp3
- turn_6_93e62fbd.mp3
- turn_7_93e62fbd.mp3
- turn_8_93e62fbd.mp3

**Use Cases:**
- TTS quality testing
- Audio playback verification
- User experience testing

---

## 📈 Data Statistics

 Category | Count | Size (est.) |
----------|-------|-------------|
 Conversation turns | 11 | ~8 KB |
 Performance metrics | 12 | ~1 KB |
 Intent types | 7 | - |
 Saved notes | 5 | ~500 bytes |
 Reminders | 5 | ~400 bytes |
 Tasks | 5 | ~1.5 KB |
 Error logs | 8 | ~800 bytes |
 Test queries | 50+ | ~3 KB |
 Demo scenarios | 5 | ~2 KB |
 Audio files | 8 | ~800 KB (est.) |

**Total Sample Data:** ~820 KB

---

## 🎯 Use Cases

### 1. Development & Testing
- Unit test data sources
- Integration testing
- Regression testing
- Performance benchmarking

### 2. Demonstration
- Hackathon presentations
- Feature showcases
- User training
- Documentation examples

### 3. Analytics & Reporting
- Intent distribution analysis
- Performance metrics visualization
- User behavior patterns
- System health monitoring

### 4. Training & Validation
- ML model training data
- Intent classifier validation
- Entity extraction testing
- Response quality assessment

---

## 🔄 Data Refresh

### When to Regenerate
- After major feature updates
- Before demos/presentations
- When adding new intents
- Performance baseline updates

### How to Regenerate
```bash
# Clear existing logs (keep structure)
rm -f data/logs/*.csv data/logs/*.txt

# Run demo mode to generate fresh data
python main.py --demo

# Or run test suite
pytest tests/ --generate-sample-data
```

---

## 📝 Data Privacy & Security

⚠️ **Important Notes:**
- All sample data is **synthetic/mock data**
- No real user information included
- Safe for public demonstrations
- No PII (Personally Identifiable Information)
- Email addresses are example.com domains
- Phone numbers are fictional

---

## 🔧 Maintenance

### Regular Tasks
- [ ] Update sample queries monthly
- [ ] Refresh conversation logs quarterly
- [ ] Validate audio files integrity
- [ ] Review performance baselines
- [ ] Archive old sample data

### Data Quality Checks
```bash
# Verify CSV structure
head -5 data/logs/*.csv

# Count records
wc -l data/logs/*.txt

# Check audio files
ls -lh data/audio_output/*.mp3
```

---

## 📚 Additional Resources

- **Main README:** `/README.md`
- **Project Structure:** `/PROJECT_STRUCTURE.md`
- **Test Guide:** `/data/audio_input/test_data_guide.txt`
- **Development Guide:** `/README_DEV.md`

---

**For questions or issues with sample data, refer to the project documentation or contact the development team.**
